Graphic Kudos - jQuery PHP Page

Files:
- index.php: complete one-page PHP website with CSS and commented jQuery.

Run locally:
1. Put the graphic_kudos_jquery_page folder inside your PHP server folder (for example, htdocs if using XAMPP).
2. Start Apache in XAMPP.
3. Open http://localhost/graphic_kudos_jquery_page/

The jQuery interactions:
- Search the project cards as you type.
- Open and close each card's extra details with a slide animation.

The page loads jQuery from the official jQuery CDN, so an internet connection is needed for the jQuery interactions.
